package CreditCardsDotCom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CardIssuerPage {
    WebDriver driver;

    // Top Menu
    public static final By companyLogoLink = By.xpath("//img[2]");
    public static final By cardIssuerLink = By.linkText("Card Issuer");
    public static final By creditRangeLink = By.linkText("Credit Range");
    public static final By resourcesLink = By.linkText("Resources");

    // Card Issuer - Top Link Menu Items
    public static final By americanExpressLink = By.linkText("American Express");
    public static final By bankOfAmericaLink = By.linkText("Bank of America");
    public static final By barclaysLink = By.linkText("Barclays");
    public static final By capitalOneLink = By.linkText("Capital One");
    public static final By chaseLink = By.linkText("Chase");
    public static final By citiLink = By.linkText("Citi");
    public static final By discoverLink = By.linkText("Discover");
    public static final By hsbcLink = By.linkText("HSBC");
    public static final By wellsFargoLink = By.linkText("Wells Fargo");
    public static final By visaLink = By.linkText("Visa");
    public static final By masterCardLink = By.linkText("Mastercard");
    
        
    // Card Issuer - Top Link Menu Item Pages
    public static final By americanExpress_Page = By.xpath("//h1[(text() = 'American Express Credit Cards')]");
    public static final By bankOfAmerica_Page = By.xpath("//h1[(text() = 'Bank of America® Credit Cards')]");
    public static final By barclays_Page = By.xpath("//h1[(text() = 'Barclays Credit Cards')]");
    public static final By capitalOne_Page = By.xpath("//h1[(text() = 'Capital One Credit Cards')]");
    public static final By chase_Page = By.xpath("//h1[(text() = 'Chase Credit Cards')]");
    public static final By citi_Page = By.xpath("//h1[(text() = 'Citi® Credit Cards')]");
    public static final By discover_Page = By.xpath("//h1[(text() = 'Discover® Credit Cards')]");
    public static final By hsbc_Page = By.xpath("//h1[(text() = 'HSBC Bank Credit Cards')]");
    public static final By wellsFargo_Page = By.xpath("//h1[(text() = 'Wells Fargo Credit Cards')]");   
    public static final By visa_Page = By.xpath("//h1[(text() = 'Visa Credit Cards')]");
    public static final By masterCard_Page = By.xpath("//h1[(text() = 'Mastercard® Credit Cards')]");
    
    
    // Constructor
    public CardIssuerPage(WebDriver driver) {
        this.driver = driver;
    }

    // TOP MENU

    public void isDisplayed(By by) {
        new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(by)));
        driver.findElement(by).isDisplayed();
    }

    public void isDisplayedThenClick(By by) {
        isDisplayed(by);
        Actions ob = new Actions(driver);
        ob.moveToElement(driver.findElement(by)).click().build().perform();
    }

  }