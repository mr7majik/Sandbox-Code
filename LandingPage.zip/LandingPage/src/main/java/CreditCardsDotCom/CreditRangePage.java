package CreditCardsDotCom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CreditRangePage {
    WebDriver driver;

    // Top Menu
    public static final By companyLogoLink = By.xpath("//img[2]");
    public static final By cardCategoryLink = By.xpath("/html/body/div[1]/header/nav/ul/li[1]/a");
    public static final By cardIssuerLink = By.linkText("Card Issuer");
    public static final By creditRangeLink = By.linkText("Credit Range");
    public static final By resourcesLink = By.linkText("Resources");

    // Card Issuer - Top Link Menu Items
    public static final By excellentCreditLink = By.linkText("Excellent Credit");
    public static final By goodCreditLink = By.linkText("Good Credit");
    public static final By fairCreditLink = By.linkText("Fair Credit");
    public static final By badCreditLink = By.linkText("Bad Credit");
    public static final By securedCreditCardsLink = By.linkText("Secured Credit Cards");
    public static final By limitedOrNoCreditHistoryLink = By.linkText("Limited or No Credit History");
    public static final By debitAndPrepaidCardsLink = By.linkText("Debit & Prepaid Cards");
     
        
    // Card Issuer - Top Link Menu Item Pages
    public static final By excellentCredit_Page = By.xpath("//h1[(text() = 'Credit Cards For Excellent Credit')]");
    public static final By goodCredit_Page = By.xpath("//h1[(text() = 'Credit Cards For Good Credit')]");
    public static final By fairCredit_Page = By.xpath("//h1[(text() = 'Credit Cards for Fair/Average Credit')]");
    public static final By badCredit_Page = By.xpath("//h1[(text() = 'Credit Cards for Bad Credit')]");
    public static final By securedCreditCards_Page = By.xpath("//h1[(text() = 'Secured Credit Cards')]");
    public static final By limitedOrNoCreditHistory_Page = By.xpath("//h1[(text() = 'Credit Cards for People with No Credit')]");
    public static final By debitAndPrepaidCards_Page = By.xpath("//h1[(text() = 'Debit Cards & Prepaid Cards')]");
        
    
    // Constructor
    public CreditRangePage(WebDriver driver) {
        this.driver = driver;
    }

    // TOP MENU

    public void isDisplayed(By by) {
        new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(by)));
        driver.findElement(by).isDisplayed();
    }

    public void isDisplayedThenClick(By by) {
        isDisplayed(by);
        Actions ob = new Actions(driver);
        ob.moveToElement(driver.findElement(by)).click().build().perform();
    }

  }