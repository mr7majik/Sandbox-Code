package CreditCardsDotCom;

import static org.testng.Assert.assertTrue;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ResourcesPage {
    WebDriver driver;

    // Top Menu
    public static final By companyLogoLink = By.xpath("//img[2]");
    public static final By cardCategoryLink = By.xpath("/html/body/div[1]/header/nav/ul/li[1]/a");
    public static final By cardIssuerLink = By.linkText("Card Issuer");
    public static final By creditRangeLink = By.linkText("Credit Range");
    public static final By resourcesLink = By.linkText("Resources");

    // Card Issuer - Top Link Menu Items
    public static final By newsAndAdviceLink = By.linkText("News & Advice");
    public static final By reviewsLink = By.linkText("Reviews");
    public static final By glossaryLink = By.linkText("Glossary");
    public static final By calculatorsLink = By.linkText("Calculators");
    public static final By cardMatchLink = By.xpath("//a[contains(text(),'CardMatch™')]");
    
        
        
    // Card Issuer - Top Link Menu Item Pages
    public static final By newsAndAdvice_Page = By.xpath("//div/div/div/div");
    public static final By reviews_Page = By.xpath("//h1[(text() = 'Credit Card Reviews')]");
    public static final By glossary_Page = By.xpath("//h1[(text() = 'Credit Card Glossary: Terms and Definitions')]");
    public static final By calculators_Page = By.xpath("//h1[(text() = 'Credit Card Calculators')]");
    public static final By cardMatch_Page = By.xpath("//div[2]/div/div");
    
    //Card Matches Application Form
    public static final By cardMatchFirstName_App = By.id("applicant-first-name");
    public static final By cardMatchLastName_App = By.id("applicant-last-name");
    public static final By cardMatchAddress_App = By.id("applicant-address");
    public static final By cardMatchCity_App = By.id("applicant-city");
    public static final By cardMatchState_App = By.id("applicant-state");
    public static final By cardMatchZip_App = By.id("applicant-zipcode");
    public static final By cardMatchSSN_App = By.id("applicant-ssn");
    public static final By getMatchesButton_App = By.xpath("//button[@type = 'submit' and (text() = 'Get Matches ')]");
    public static final By exceptionErrorMsg = By.xpath("//div[(text() = 'Must enter valid 4-digit SSN.')]");
  
    
    // Constructor
    public ResourcesPage(WebDriver driver) {
        this.driver = driver;
    }

    // TOP MENU

    public void isDisplayed(By by) {
        new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(by)));
        driver.findElement(by).isDisplayed();
    }

    public void isDisplayedThenClick(By by) {
        isDisplayed(by);
        Actions ob = new Actions(driver);
        ob.moveToElement(driver.findElement(by)).click().build().perform();
    }
    
    public void submitApplication() {
    	WebElement firstname = driver.findElement(cardMatchFirstName_App);
    	firstname.click();
    	firstname.sendKeys("Mister");
    	
    	WebElement lastname = driver.findElement(cardMatchLastName_App);
    	lastname.click();
    	lastname.sendKeys("Tester");
    	
    	WebElement address = driver.findElement(cardMatchAddress_App);
    	address.click();
    	address.sendKeys("111 Main Street");
    	
    	WebElement city = driver.findElement(cardMatchCity_App);
    	city.click();
    	city.sendKeys("Austin");
    	
    	WebElement state = driver.findElement(cardMatchState_App);
    	state.click();
    	state.sendKeys("TX");
    	
    	WebElement zip = driver.findElement(cardMatchZip_App);
    	zip.click();
    	zip.sendKeys("78664");
    	
    	WebElement ssn = driver.findElement(cardMatchSSN_App);
    	ssn.click();
    	ssn.sendKeys("1111111111111111");
    	
    	WebElement getmatchesbtn = driver.findElement(getMatchesButton_App);
    	getmatchesbtn.click();
    	
    	String actualString = driver.findElement(By.xpath("//div[(text() = 'Must enter valid 4-digit SSN.')]")).getText();
    	assertTrue(actualString.contains("Must enter valid 4-digit SSN."));
    	System.out.println("Exception Message Appears: " + actualString);
    }
 }