package CreditCardsDotCom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CardCategoryPage {
    WebDriver driver;

    // Top Menu
    public static final By companyLogoLink = By.xpath("//img[2]");
    public static final By cardCategoryLinkL = By.partialLinkText("Card Category");
    public static final By cardCategoryLink = By.xpath("/html/body/div[1]/header/nav/ul/li[1]/a");
    // public static final By cardCategoryLink = By.cssSelector("body > div.boxy > header > nav > ul > li:nth-child(1)");
    public static final By cardIssuerLink = By.linkText("Card Issuer");
    public static final By creditRangeLink = By.linkText("Credit Range");
    public static final By resourcesLink = By.linkText("Resources");

    // Sub Menu Links - Best Credit Cards
    public static final By bestCreditCardsLink = By.linkText("Best Credit Cards");
    public static final By rewardsLink = By.linkText("Rewards");
    public static final By signupBonusesLink = By.linkText("Sign Up Bonuses");
    public static final By cashBackLink = By.linkText("Cash Back");
    public static final By balanceTransferlink = By.linkText("Balance Transfer");
    public static final By zeroPercentAprLink = By.linkText("0% APR");
    public static final By noAnnualFeeLink = By.linkText("No Annual Fee");
    public static final By lowInterestLink = By.linkText("Low Interest");
    public static final By travelLink = By.linkText("Travel");
    public static final By airlineLink = By.linkText("Airline");
    public static final By hotelLink = By.linkText("Hotel");
    public static final By noForeignTransactionFeeLink = By.linkText("No Foreign Transaction Fee");
    public static final By businessLink = By.linkText("Business");
    public static final By studentLink = By.linkText("Student");
    public static final By gasLink = By.linkText("Gas");

    // Best Credit Cards - Filter Cards By Category - Links
    public static final By allCategoriesLink = By.xpath("//div[2]/ul/li");
    public static final By sign_upBonusesLink = By.xpath("//div[2]/ul/li[2]");
    public static final By flatRateCashbackLink = By.xpath("//div[2]/ul/li[3]");
    public static final By everydayCashbackLink = By.xpath("//div[2]/ul/li[4]");
    public static final By travelRewardsLink = By.xpath("//div[2]/ul/li[5]");
    public static final By rewards_Link = By.xpath("//div[2]/ul/li[6]");
    public static final By zero_PercentAprLink = By.xpath("//div[2]/ul/li[7]");
    public static final By moreButtonLink = By.xpath("//div[2]/ul/li[8]");

    // Best Credit Cards - Filter Cards By Category - Pages
    public static final By bestCreditCardsOf2019_Page = By.xpath("//h1");
    public static final By bestSignupBonusCreditCard_Page = By.xpath("//div/div/div/h2");
    public static final By bestCashbackCreditCardForFlatRateRewards_Page = By.xpath("//div[2]/div/div/div/h2");
    public static final By bestCashbackCreditCardForEverydaySpending_Page = By.xpath("//div[3]/div/div/div/h2");
    public static final By bestTravelRewardsCreditCard_Page = By.xpath("//div[4]/div/div/div/h2");
    public static final By bestRewardsCreditCard_Page = By.xpath("//div[5]/div/div/div/h2");
    public static final By bestZeroPercentAprCreditCard_Page = By.xpath("//div[6]/div/div/div/h2");

    //More Button Options - Links
    public static final By no_AnnualFeeLink = By.xpath("//div[2]/ul[2]/li");
    public static final By balance_TransferLink = By.xpath("//div[2]/ul[2]/li[2]");
    public static final By diningLink = By.xpath("//div[2]/ul[2]/li[3]");
    public static final By gas_Link = By.xpath("//div[2]/ul[2]/li[4]");
    public static final By low_InterestLink = By.xpath("//ul[2]/li[5]");
    public static final By no_ForeignTransactionFeeLink = By.xpath("//ul[2]/li[6]");
    public static final By airlineMilesLink = By.xpath("//ul[2]/li[7]");
    public static final By business_Link = By.xpath("//ul[2]/li[8]");
    public static final By fairCreditLink = By.xpath("//ul[2]/li[9]");
    public static final By badCreditLink = By.xpath("//ul[2]/li[10]");
    public static final By student_Link = By.xpath("//ul[2]/li[11]");

    //More Button Options - Pages
    public static final By bestNoAnnualFeeCreditCard_Page = By.xpath("//div[7]/div/div/div/h2");
    public static final By bestBalanceTransferCreditCard_Page = By.xpath("//div[8]/div/div/div/h2");
    public static final By bestDiningCreditCard_Page = By.xpath("//div[9]/div/div/div/h2");
    public static final By bestGasCreditCard_Page = By.xpath("//div[10]/div/div/div/h2");
    public static final By bestLowInterestCreditCard_Page = By.xpath("//div[11]/div/div/div/h2");
    public static final By bestNoForeignTransactionFeeCreditCard_Page = By.xpath("//div[12]/div/div/div/h2");
    public static final By bestAirlineMilesCreditCard_Page = By.xpath("//div[13]/div/div/div/h2");
    public static final By bestBusinessCreditCard_Page = By.xpath("//div[14]/div/div/div/h2");
    public static final By bestFairCreditCreditCard_Page = By.xpath("//div[15]/div/div/div/h2");
    public static final By bestCreditCardForBadcredit_Page = By.xpath("//div[16]/div/div/div/h2");
    public static final By bestStudentCreditCard_Page = By.xpath("//div[17]/div/div/div/h2");



    //	// Constructor
    public CardCategoryPage(WebDriver driver) {
        this.driver = driver;
    }

    // TOP MENU

    public void isDisplayed(By by) {
        new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(by)));
        driver.findElement(by).isDisplayed();
    }

    public void isDisplayedThenClick(By by) {
        isDisplayed(by);
        Actions ob = new Actions(driver);
        ob.moveToElement(driver.findElement(by)).click().build().perform();
    }

  
    public void verifyBestCashBackCreditCardForFlatRateRewardsPage() {
        driver.findElement(bestCashbackCreditCardForFlatRateRewards_Page).isDisplayed();
    }

  }