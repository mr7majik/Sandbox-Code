package CreditCardsDotCom;

import org.openqa.selenium.WebDriver;

public class ActiveDriverStore {

    private static WebDriver driver=null;

    public static WebDriver getDriver() {
        return driver;
    }

    public static void setDriver(WebDriver driver) {
        ActiveDriverStore.driver = driver;
    }

    public static void destroy() {
        if(driver != null){
            driver.quit();
            driver = null;
        }
    }

    public static boolean exists(){
        return driver != null;
    }

}
