
  package CreditCardsDotCom;
  
  import org.openqa.selenium.WebDriver;
  import org.openqa.selenium.chrome.ChromeDriver;
  import org.testng.annotations.BeforeSuite;
  
  public class LoginPage 
  {
	  
	 public static WebDriver driver;
	 String baseurl = "https://www.creditcards.com";
  
	 @BeforeSuite
	 public void openBrowser()
	 {
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 				 
	 }
	 
  }
 
