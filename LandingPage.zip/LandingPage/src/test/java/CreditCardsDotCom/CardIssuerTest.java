package CreditCardsDotCom;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static CreditCardsDotCom.BaseTest.startBrowser;

import java.util.concurrent.TimeUnit;

public class CardIssuerTest {

	  @BeforeMethod
	  public void verifyAppWorking() throws InterruptedException {
	  
		  WebDriver driver = startBrowser(); CardIssuerPage cip = new
		  CardIssuerPage(driver); //Verify Landing Page Top Links
	  
		  cip.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
		  driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		  cip.isDisplayedThenClick(CardCategoryPage.cardIssuerLink);
		  driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		  cip.isDisplayedThenClick(CardCategoryPage.creditRangeLink);
		  driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS); 
		  cip.isDisplayedThenClick(CardCategoryPage.resourcesLink);
		  driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
	  
		  driver.quit(); 
	  }
	 
		
	  @Test
	  public void verifyCardIssuerSubMenuLinks() throws InterruptedException{
		  
		  WebDriver driver = startBrowser();
		  CardIssuerPage cip = new CardIssuerPage(driver);
	    
		  //American Express
		  cip.isDisplayedThenClick(CardIssuerPage.cardIssuerLink);
		  cip.isDisplayedThenClick(CardIssuerPage.americanExpressLink);
		  cip.isDisplayed(CardIssuerPage.americanExpress_Page);
		  driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
	    
		  //Bank of American
		  cip.isDisplayedThenClick(CardIssuerPage.cardIssuerLink);
		  cip.isDisplayedThenClick(CardIssuerPage.bankOfAmericaLink);
		  cip.isDisplayed(CardIssuerPage.bankOfAmerica_Page);
		  driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
		  //Barclays
	      cip.isDisplayedThenClick(CardIssuerPage.cardIssuerLink);
	      cip.isDisplayedThenClick(CardIssuerPage.barclaysLink);
	      cip.isDisplayed(CardIssuerPage.barclays_Page);
	      driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
	        
	      //Capital One
	      cip.isDisplayedThenClick(CardIssuerPage.cardIssuerLink);
	      cip.isDisplayedThenClick(CardIssuerPage.capitalOneLink);
	      cip.isDisplayed(CardIssuerPage.capitalOne_Page);
	      driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
          //Capital One
          cip.isDisplayedThenClick(CardIssuerPage.cardIssuerLink);
          cip.isDisplayedThenClick(CardIssuerPage.chaseLink);
          cip.isDisplayed(CardIssuerPage.chase_Page);
          driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
          //Citi
          cip.isDisplayedThenClick(CardIssuerPage.cardIssuerLink);
          cip.isDisplayedThenClick(CardIssuerPage.citiLink);
          cip.isDisplayed(CardIssuerPage.citi_Page);
          driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
          //Discover
          cip.isDisplayedThenClick(CardIssuerPage.cardIssuerLink);
          cip.isDisplayedThenClick(CardIssuerPage.discoverLink);
          cip.isDisplayed(CardIssuerPage.discover_Page);
          driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
          //HSBC
          cip.isDisplayedThenClick(CardIssuerPage.cardIssuerLink);
          cip.isDisplayedThenClick(CardIssuerPage.hsbcLink);
          cip.isDisplayed(CardIssuerPage.hsbc_Page);
          driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
          //Wells Fargo
          cip.isDisplayedThenClick(CardIssuerPage.cardIssuerLink);
          cip.isDisplayedThenClick(CardIssuerPage.wellsFargoLink);
          cip.isDisplayed(CardIssuerPage.wellsFargo_Page);
          driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
          //Visa
          cip.isDisplayedThenClick(CardIssuerPage.cardIssuerLink);
          cip.isDisplayedThenClick(CardIssuerPage.visaLink);
          cip.isDisplayed(CardIssuerPage.visa_Page);
          driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
          //Mastercard
          cip.isDisplayedThenClick(CardIssuerPage.cardIssuerLink);
          cip.isDisplayedThenClick(CardIssuerPage.masterCardLink);
          cip.isDisplayed(CardIssuerPage.masterCard_Page);
          driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
          driver.quit(); 
	  }   
 }
	


	
	
	
	
	
	
	
	
	





 
