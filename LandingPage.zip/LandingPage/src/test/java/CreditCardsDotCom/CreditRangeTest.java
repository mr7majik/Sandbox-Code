package CreditCardsDotCom;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static CreditCardsDotCom.BaseTest.startBrowser;

import java.util.concurrent.TimeUnit;

public class CreditRangeTest {

	  @BeforeMethod
	  public void verifyAppWorking() throws InterruptedException {
	  
		  WebDriver driver = startBrowser(); 
		  CreditRangePage crp = new CreditRangePage(driver); //Verify Landing Page Top Links
	  
		  crp.isDisplayedThenClick(CreditRangePage.cardCategoryLink);
		   driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		  crp.isDisplayedThenClick(CreditRangePage.cardIssuerLink);
		   driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		  crp.isDisplayedThenClick(CreditRangePage.creditRangeLink);
		   driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS); 
		  crp.isDisplayedThenClick(CreditRangePage.resourcesLink);
		   driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
	  
		  driver.quit(); 
	  }
	 
	  @Test
	  public void verifyCardIssuerSubMenuLinks() throws InterruptedException{
		  
		  WebDriver driver = startBrowser();
		  CreditRangePage crp = new CreditRangePage(driver);
	    
		  //Excellent Credit
		  crp.isDisplayedThenClick(CreditRangePage.creditRangeLink);
		  crp.isDisplayedThenClick(CreditRangePage.excellentCreditLink);
		  crp.isDisplayed(CreditRangePage.excellentCredit_Page);
		   driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
	    
		  //Good Credit
		  crp.isDisplayedThenClick(CreditRangePage.creditRangeLink);
		  crp.isDisplayedThenClick(CreditRangePage.goodCreditLink);
		  crp.isDisplayed(CreditRangePage.goodCredit_Page);
		   driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
		  //Fair Credit
	      crp.isDisplayedThenClick(CreditRangePage.creditRangeLink);
	      crp.isDisplayedThenClick(CreditRangePage.fairCreditLink);
	      crp.isDisplayed(CreditRangePage.fairCredit_Page);
	       driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
	        
	      //Bad Credit
	      crp.isDisplayedThenClick(CreditRangePage.creditRangeLink);
	      crp.isDisplayedThenClick(CreditRangePage.badCreditLink);
	      crp.isDisplayed(CreditRangePage.badCredit_Page);
	       driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
          //Secured Credit Cards
          crp.isDisplayedThenClick(CreditRangePage.creditRangeLink);
          crp.isDisplayedThenClick(CreditRangePage.securedCreditCardsLink);
          crp.isDisplayed(CreditRangePage.securedCreditCards_Page);
           driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
          //Limited or No Credit History
          crp.isDisplayedThenClick(CreditRangePage.creditRangeLink);
          crp.isDisplayedThenClick(CreditRangePage.limitedOrNoCreditHistoryLink);
          crp.isDisplayed(CreditRangePage.limitedOrNoCreditHistory_Page);
           driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
          //Debit & Prepaid Cards
          crp.isDisplayedThenClick(CreditRangePage.creditRangeLink);
          crp.isDisplayedThenClick(CreditRangePage.debitAndPrepaidCardsLink);
          crp.isDisplayed(CreditRangePage.debitAndPrepaidCards_Page);
           driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
             
          driver.quit(); 
	  }   
 }
	


	
	
	
	
	
	
	
	
	





 
