package CreditCardsDotCom;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static CreditCardsDotCom.BaseTest.startBrowser;

import java.util.concurrent.TimeUnit;

public class ResourcesTest {

	  @BeforeMethod
	  public void verifyAppWorking() throws InterruptedException {
	  
		  WebDriver driver = startBrowser(); 
		  ResourcesPage rp = new ResourcesPage(driver); //Verify Landing Page Top Links
	  
		  rp.isDisplayedThenClick(ResourcesPage.cardCategoryLink);
		   driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		  rp.isDisplayedThenClick(ResourcesPage.cardIssuerLink);
		   driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		  rp.isDisplayedThenClick(ResourcesPage.creditRangeLink);
		   driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS); 
		  rp.isDisplayedThenClick(ResourcesPage.resourcesLink);
		   driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
	  
		  driver.quit(); 
	  }
	 
	  @Test
	  public void verifyCardIssuerSubMenuLinks() throws InterruptedException{
		  
		  WebDriver driver = startBrowser();
		  ResourcesPage crp = new ResourcesPage(driver);
	    
		  //News and Advice
		  crp.isDisplayedThenClick(ResourcesPage.resourcesLink);
		  crp.isDisplayedThenClick(ResourcesPage.newsAndAdviceLink);
		  crp.isDisplayed(ResourcesPage.newsAndAdvice_Page);
		   driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
	    
		  //Reviews
		  crp.isDisplayedThenClick(ResourcesPage.resourcesLink);
		  crp.isDisplayedThenClick(ResourcesPage.reviewsLink);
		  crp.isDisplayed(ResourcesPage.reviews_Page);
		   driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
		  //Glossary
	      crp.isDisplayedThenClick(ResourcesPage.resourcesLink);
	      crp.isDisplayedThenClick(ResourcesPage.glossaryLink);
	      crp.isDisplayed(ResourcesPage.glossary_Page);
	       driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
	        
	      //Calculators
	      crp.isDisplayedThenClick(ResourcesPage.resourcesLink);
	      crp.isDisplayedThenClick(ResourcesPage.calculatorsLink);
	      crp.isDisplayed(ResourcesPage.calculators_Page);
	       driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
          //CardMatch
          crp.isDisplayedThenClick(ResourcesPage.resourcesLink);
          crp.isDisplayedThenClick(ResourcesPage.cardMatchLink);
          crp.isDisplayed(ResourcesPage.cardMatch_Page);
          Thread.sleep(2000);
          
          //Verify Get Matches Application
          
          crp.submitApplication();
                            
          driver.quit(); 
	  }   
 }
	


	
	
	
	
	
	
	
	
	





 
