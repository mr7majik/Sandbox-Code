package CreditCardsDotCom;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;

public class BaseTest {

    @BeforeTest
	public static WebDriver startBrowser() {
        
        WebDriver driver;
        
        //Multiple Browsers
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\ajama\\chromedriver_win32\\chromedriver.exe");
        driver=new ChromeDriver();
        
        //System.setProperty("webdriver.gecko.driver","C:\\Users\\ajama\\geckodriver-v0.24.0-win64\\geckodriver.exe");
        //driver=new FirefoxDriver();

        //Maximize and Open the Application
        driver.manage().window().maximize();
        driver.get("http://www.creditcards.com");
        return driver;
    }

    public static WebDriver getDriver() {
        WebDriver driver = ActiveDriverStore.getDriver();
        //Maximize the Browser window
        driver.manage().window().maximize();
        return driver;
    }

    
    //Pass a string that contains both values in with and without quotes. If the value contains quotes, group them together similar like a search engine function.
    public static String pingSplitter(String testPing) {
    	ArrayList<String> al = new ArrayList<String>();
    	Matcher pingMatch = Pattern.compile("([^\"]\\S*|\".+?\")\\s*").matcher(testPing);
    	
    	while(pingMatch.find())
    		al.add(pingMatch.group(1));
    	System.out.print(testPing);
    	return testPing;
    }
    
    public static void main (String[] args) {
    	String s = "tacos\"at midnight\"";
    	pingSplitter(s);
    }
    
    
}
