package CreditCardsDotCom;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import static CreditCardsDotCom.BaseTest.startBrowser;
import static CreditCardsDotCom.CardCategoryPage.*;

import java.util.concurrent.TimeUnit;


public class CardCategoryTest {

	@BeforeTest
    public void verifyAppWorking() throws InterruptedException
    {
    	WebDriver driver = startBrowser();
        CardCategoryPage ccp = new CardCategoryPage(driver);
        //Verify Landing Page Top Links
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayedThenClick(CardCategoryPage.cardIssuerLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayedThenClick(CardCategoryPage.creditRangeLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayedThenClick(CardCategoryPage.resourcesLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
        driver.quit();
    }
	
	
	@BeforeMethod
    public void verifyCardCategorySubMenuLinks() throws InterruptedException{
		WebDriver driver = startBrowser();
        CardCategoryPage ccp = new CardCategoryPage(driver);
        
        //Best Credit Cards
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        ccp.isDisplayedThenClick(CardCategoryPage.bestCreditCardsLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
        //Rewards
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        ccp.isDisplayedThenClick(CardCategoryPage.rewardsLink);
        
        //Sign Up Bonuses
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        ccp.isDisplayedThenClick(CardCategoryPage.signupBonusesLink);
        new WebDriverWait(driver, 45).until(ExpectedConditions.urlContains("signup-bonuses"));
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
        //Cash Back
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        ccp.isDisplayedThenClick(CardCategoryPage.cashBackLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        //Balance Transfer
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        ccp.isDisplayedThenClick(CardCategoryPage.balanceTransferlink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        //0% APR
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        ccp.isDisplayedThenClick(CardCategoryPage.zeroPercentAprLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        //No Annual Fee
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        ccp.isDisplayedThenClick(CardCategoryPage.noAnnualFeeLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        //Low Interest
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        ccp.isDisplayedThenClick(CardCategoryPage.lowInterestLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        //Travel
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        ccp.isDisplayedThenClick(CardCategoryPage.travelLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        //Airline
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        ccp.isDisplayedThenClick(CardCategoryPage.airlineLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        //Hotel
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        ccp.isDisplayedThenClick(CardCategoryPage.hotelLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        //No Foreign Transaction
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        ccp.isDisplayedThenClick(CardCategoryPage.noForeignTransactionFeeLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        //Business
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        ccp.isDisplayedThenClick(CardCategoryPage.businessLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        //Student
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        ccp.isDisplayedThenClick(CardCategoryPage.studentLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        //Gas
        ccp.isDisplayedThenClick(CardCategoryPage.cardCategoryLink);
        ccp.isDisplayedThenClick(CardCategoryPage.gasLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        driver.quit();
    }
 
	@Test
	public void VerifySubMenuLinkPages()throws InterruptedException
	{
		WebDriver driver = startBrowser();
        CardCategoryPage ccp = new CardCategoryPage(driver);
        
        //Best Credit Cards Page
        ccp.isDisplayedThenClick(cardCategoryLink);
        ccp.isDisplayedThenClick(bestCreditCardsLink);
        ccp.isDisplayed(bestBusinessCreditCard_Page);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
	
        //Sign Up Bonus Page
        ccp.isDisplayedThenClick(sign_upBonusesLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestSignupBonusCreditCard_Page);
	
        //Flat-Rate Cash Back Page
        ccp.isDisplayedThenClick(flatRateCashbackLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.driver.findElement(bestCashbackCreditCardForFlatRateRewards_Page).isDisplayed();
                
        //Everyday Cash Back
        ccp.isDisplayedThenClick(everydayCashbackLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestCashbackCreditCardForEverydaySpending_Page);
                
        //Travel Rewards
        ccp.isDisplayedThenClick(travelRewardsLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestTravelRewardsCreditCard_Page);
                
        //Rewards
        ccp.isDisplayedThenClick(rewards_Link);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestRewardsCreditCard_Page);
                
        //0% APR
        ccp.isDisplayedThenClick(zero_PercentAprLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestZeroPercentAprCreditCard_Page);
        
        //Verify More Button Drop Down Menu Item Links
        ccp.isDisplayedThenClick(moreButtonLink);

        ccp.isDisplayedThenClick(no_AnnualFeeLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestNoAnnualFeeCreditCard_Page);

        ccp.isDisplayedThenClick(moreButtonLink);
        ccp.isDisplayedThenClick(no_ForeignTransactionFeeLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestNoForeignTransactionFeeCreditCard_Page);

        ccp.isDisplayedThenClick(moreButtonLink);
        ccp.isDisplayedThenClick(airlineMilesLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestAirlineMilesCreditCard_Page);

        ccp.isDisplayedThenClick(moreButtonLink);
        ccp.isDisplayedThenClick(business_Link);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestBusinessCreditCard_Page);

        ccp.isDisplayedThenClick(moreButtonLink);
        ccp.isDisplayedThenClick(fairCreditLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestFairCreditCreditCard_Page);

        ccp.isDisplayedThenClick(moreButtonLink);
        ccp.isDisplayedThenClick(balance_TransferLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestBalanceTransferCreditCard_Page);

        ccp.isDisplayedThenClick(moreButtonLink);
        ccp.isDisplayedThenClick(diningLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestDiningCreditCard_Page);

        ccp.isDisplayedThenClick(moreButtonLink);
        ccp.isDisplayedThenClick(gas_Link);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestGasCreditCard_Page);

        ccp.isDisplayedThenClick(moreButtonLink);
        ccp.isDisplayedThenClick(low_InterestLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestLowInterestCreditCard_Page);

        ccp.isDisplayedThenClick(moreButtonLink);
        ccp.isDisplayedThenClick(badCreditLink);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestCreditCardForBadcredit_Page);

        ccp.isDisplayedThenClick(moreButtonLink);
        ccp.isDisplayedThenClick(student_Link);
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        ccp.isDisplayed(bestStudentCreditCard_Page);
        
        driver.quit();
	} 
}

 
